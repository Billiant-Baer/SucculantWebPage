function clickAlert(){
    alert('Your cart is empty')   
}

function hoverover(img){
img.src= "succulents-2.jpg"
}
function hoverout(img){
    img.src= "succulents-1.jpg"
}

   
function hide(element) {
        element.remove();
}